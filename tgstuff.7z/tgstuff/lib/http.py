import time
import pprint
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys


class Website(object):
    def __init__(self):
        # chrome_options = Options()
        # chrome_options.add_argument("--headless")
        self.driver = webdriver.Chrome('C:/Users/home/Downloads/chromedriver_win32/chromedriver.exe')
        self.site_name = None
        self.new_links = None
        self.old_links = None
        pass

    def generate(self):
        # generates the actual traffic
        pass

    def check_link(self, link):
        if self.site_name:
            if self.site_name + "/" in link:
                return True
        return False
        pass


class ReadTheDocsOrg(Website):
    def __init__(self):
        super().__init__()
        self.site_name = "readthedocs.org"
        self.new_links = []
        self.old_links = []

    def generate(self):
        self.browse()
        pass

    def browse(self):
        print("[+] Browse readthedocs.org")

        # start at the target start page
        fetch_url = 'https://readthedocs.org/'
        self.new_links.append(fetch_url)

        # loop until no new links
        i = 0
        while i < len(self.new_links):

            # pop the first element in the list and fetch it
            fetch_url = self.new_links.pop()
            print("[!] Fetch:", fetch_url)
            try:
                self.driver.get(fetch_url)
                time.sleep(1)
            except Exception as err:
                print(err)
                continue

            # add it to the list of already visited links
            self.old_links.append(fetch_url)

            # pull all links on the page
            elems = self.driver.find_elements_by_tag_name('a')
            for elem in elems:
                href = elem.get_attribute('href')
                if href is not None:
                    # print("  Links on page <", href, "> in parent domain:", self.check_link(href))

                    # ensure that the link is in the parent domain and is actually new
                    if (self.check_link(href)) and (href not in self.old_links) and (href not in self.new_links):
                        self.new_links.append(href)

            # print the list
            print("----New Links (", len(self.new_links), ") ----")
            pprint.pprint(self.new_links)
            print("-----------------")
            print("")

        time.sleep(3)
        print("----Visited Links (", len(self.old_links), ") ----")
        pprint.pprint(self.old_links)
        print("-----------------")
        print("")
        self.driver.close()
