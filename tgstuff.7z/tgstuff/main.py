# Imports
import lib.http as http


class User:
    def __init__(self, config=True, username=False, password=False):
        self.username = username
        self.password = password
        self.config = config
        if config:
            # self.config should point to a json configuration file
            # parse the config and generate the traffic
            # self.parse_config()
            # TODO: for now , just set some config options
            self.traffic = http.ReadTheDocsOrg()

    def parse_config(self):
        pass

    def generate(self):
        self.traffic.generate()
        pass


if __name__ == '__main__':
    bob = User()
    bob.generate()


